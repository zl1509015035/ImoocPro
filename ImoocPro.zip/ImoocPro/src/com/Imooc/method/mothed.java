package com.Imooc.method;

public class mothed {
}
