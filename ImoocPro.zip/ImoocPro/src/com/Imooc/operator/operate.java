package com.Imooc.operator;

public class operate {
}
